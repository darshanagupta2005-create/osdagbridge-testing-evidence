OsdagBridge functional testing evidence
Local source revision d74f56d, Windows, Python 3.12.16, osdagbridge-env.

inputs/ contains four original snapshots. inputs3.osi and inputsadditional.osi
are byte-identical. screenshots/ contains all eight supplied captures:
E01 Additional Inputs override preview
E02 initial Basic Inputs
E03 baseline 3D model and deck tooltip
E04 baseline Design Report dialog and cross-bracing timing
E05 G1 on DD
E06 G4 on WL Transverse
E07 G3 on WL Transverse
E08 Run 2 model and analysis completion

With osdagbridge-env active, put the checkout's src directory on PYTHONPATH.
From the bundle root, run python scripts/save_probe.py, python scripts/replay.py
or python scripts/material_probe.py.
The replay may take several minutes. It uses the listed .osi files in order on
a single backend instance and runs a fourth direct-input geometry control.

logs/ contains the independent testing output. The original manual Run 3 log
and handwritten matrix were cited in the test notes. GitHub-Issue-Drafts.md
contains five issue descriptions for duplicate screening and filing.
