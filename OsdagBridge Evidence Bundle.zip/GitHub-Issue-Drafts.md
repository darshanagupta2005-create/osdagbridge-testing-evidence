# OsdagBridge issue drafts

Local revision d74f56d. Independent tests ran on Windows, Python 3.12.16, in osdagbridge-env. Source paths below are relative to src/osdagbridge. The included screenshots, inputs, and logs can be attached to the corresponding issue.

## OSB 01 — Save Input resets custom girder spacing and deck thickness

**Reproduce**

1. Load the 45.0 m / 12.5 m configuration from inputs3.osi.
2. In Additional Inputs, enter 4 girders, 4.00 m spacing and 390 mm deck thickness. The preview shows 0.70 m overhang. Click Save.
3. Use Save Input and inspect the exported .osi. The independent probe runs the same save-preparation function used by this action.

**Expected** — The .osi retains 4.00 m spacing, 390 mm deck and 0.70 m overhang.

**Observed** — inputsadditional.osi contains 3.35 m spacing, 250 mm deck and 1.675 m overhang. The probe reproduces all three mutations. The original Run 3 notes also report 3350 mm and 250 mm in the design log. Capture the live dictionary immediately before Design to isolate how the original run received those values.

**Suggested fix** — In desktop/ui/template_page.py:793–799, serialize the committed input state. Split default population from layout recomputation in core/bridge_types/plate_girder/defaults.py:181–185 and :918–936. Seed missing deck fields and preserve valid explicit geometry. Reuse this rule for Design preparation. Regression test Save Input, reload and design with the same committed values.

**Evidence** — Screenshot E01, inputs3.osi, inputsadditional.osi, save_probe.py, save_probe.log.

## OSB 02 — IRC 22 design checks treat two overhang edge lines as main girders

**Reproduce** — Run inputs.osi (30.0 m, 8.5 m, four main girders, positive overhang). Compare the input count and IRC 22 member list.

**Expected** — Check four main girders G1–G4. Identify the edge lines separately.

**Observed** — The replay reports six checked members, G1–G6. The input still has four main girders.

**Suggested fix** — In core/bridge_types/plate_girder/plategirderbridge.py:2296, pass the actual grillage edge distance when constructing PlateGirderAnalysisResults. The missing argument defaults to zero in analysis_results.py:148 and prevents the edge lines from receiving EB1 and EB2 names in build_girders(). Exclude edge lines and normalize main member labels consistently with the section and demand mapping. Use bridge._girder_count() for the design-config count in designer.py:401. Compare positive and zero overhang cases, including the assignment of distinct exterior/interior sections.

**Evidence** — inputs.osi and replay.log, IRC 22 Step 2.

## OSB 03 — PASS WARN FAIL summary does not identify excluded stiffener checks

**Reproduce** — Run inputs.osi and compare the baseline check table to the PASS / WARN / FAIL line. The replay displayed FAIL for checks 8 and 20 and a summary of 13 / 0 / 1.

**Expected** — Label what the headline counts and surface failed stiffener checks in their own tally if the category total intentionally excludes them.

**Observed** — The unqualified baseline count shows one failure while the detail table shows two. The 45.0 m replay independently reproduced the original 12 / 0 / 2 summary with three marked failures, checks 8 (fatigue normal stress), 9 (fatigue shear stress) and 20 (intermediate stiffener leg limit).

**Suggested fix** — In core/bridge_types/plate_girder/designer.py:2426–2453 and :2778, retain the existing category tally and name its scope in the display. Add a stiffener tally using the rows printed by the stiffener report section. Verify that a failed stiffener remains visible in the summary without changing the category tally.

**Evidence** — inputs.osi and replay.log, baseline check table and summary.

## OSB 04 — Custom girder unit weight is replaced in the material DTO

**Reproduce** — Start from inputs.osi and run material_probe.py. The probe enters a custom steel grade with 70 kN/m³ unit weight, 410 MPa yield strength, 525 MPa ultimate strength and 205 GPa modulus. It also enters a custom deck with 46 MPa strength and 36 GPa modulus.

**Expected** — Material resolution returns 70,000 N/m³ for the custom steel.

**Observed** — The input dictionary has 70 kN/m³. The material DTO uses 78,500 N/m³ while preserving the custom strength and modulus. The test isolates material resolution. Verify the downstream impact on each weight consumer separately.

**Suggested fix** — In core/bridge_types/plate_girder/plategirderbridge.py:1169–1216, use material.girder.density for a custom grade with a valid entered unit weight. Convert kN/m³ to N/m³ at the DTO boundary and add a regression that asserts 70,000 N/m³.

**Evidence** — material_probe.py and material_probe.log.

## OSB 05 — Analysis deck layout uses a 0.50 m barrier despite a saved 0.45 m width

**Reproduce** — Replay inputs.osi and inputs2.osi. Compare the saved crash barrier width, the CAD overall width, and the analysis log line Bridge width from layout.

**Expected** — All outputs use the committed 0.45 m per-side barrier width and the same overall width.

**Observed** — The geometry DTO uses 0.50 m per side. The analysis logs 9.50 m and 11.50 m, respectively. The corresponding CAD and saved widths are 9.40 m and 11.40 m.

**Suggested fix** — In core/bridge_types/plate_girder/plategirderbridge.py:1017–1025, use the same resolved barrier geometry as the input layout solver in defaults.py:909. Verify overall width, main-girder centerlines and load placement using two valid barrier widths.

**Evidence** — inputs.osi, inputs2.osi, screenshots E03/E08, material_probe.log and replay.log.
