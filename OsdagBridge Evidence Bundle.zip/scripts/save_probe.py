from pathlib import Path
import yaml
from osdagbridge.core.bridge_types.plate_girder.defaults import solve_extend_basic_input_dict
from osdagbridge.core.bridge_types.plate_girder.plategirderbridge import PlateGirderBridge
data = yaml.safe_load((Path.home()/'OneDrive/Desktop/osdag/inputs3.osi').read_text(encoding='utf-8-sig'))
keys = ('typical_section.girder_spacing','typical_section.deck_thickness','typical_section.deck_overhang')
data.update(dict(zip(keys,(4.0,390.0,0.7))))
print('Before save preparation', [data[k] for k in keys])
solve_extend_basic_input_dict(data)
print('After save preparation', [data[k] for k in keys])
b = PlateGirderBridge()
b.set_input(data)
b._solve_bridge_layout()
b._build_dtos()
print('Backend accepted', [b.output_dict[k] for k in keys], 'structural girders', b._girder_count(), 'longitudinal lines', b.grillage_geometry.n_l)
