from pathlib import Path
import yaml
from osdagbridge.core.bridge_types.plate_girder.plategirderbridge import PlateGirderBridge
data = yaml.safe_load((Path.home()/'OneDrive/Desktop/osdag/inputs.osi').read_text(encoding='utf-8-sig'))
data.update({'material.girder':'QA Custom Steel','material.girder.fy':410,'material.girder.fu':525,'material.girder.e':205,'material.girder.density':70,'material.deck':'QA Custom Concrete','material.deck.fck':46,'material.deck.ecm':36,'material.deck.density':23})
b=PlateGirderBridge()
b.set_input(data)
b._solve_bridge_layout()
b._build_dtos()
print('INPUT', {k:b.input_dict[k] for k in data if k in ('material.girder','material.girder.fy','material.girder.e','material.girder.density','material.deck','material.deck.fck','material.deck.ecm','material.deck.density')})
print('MATERIAL DTO', b._build_material_props())
print('LAYOUT DTO',b.deck_layout)
