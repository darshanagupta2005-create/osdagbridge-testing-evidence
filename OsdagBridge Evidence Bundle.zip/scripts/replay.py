from pathlib import Path
import yaml
from osdagbridge.core.bridge_types.plate_girder.plategirderbridge import PlateGirderBridge

if __name__ == "__main__":
    folder = Path(__file__).resolve().parents[1] / 'inputs'
    bridge = PlateGirderBridge()
    keys = ('geometry.span', 'geometry.carriageway_width', 'typical_section.no_of_girders', 'typical_section.girder_spacing', 'typical_section.deck_thickness', 'typical_section.deck_overhang', 'material.deck.fck', 'material.girder.fy')
    for name in ('inputs.osi','inputs2.osi','inputs3.osi','custom-control'):
        data = yaml.safe_load((folder / ('inputs3.osi' if name == 'custom-control' else name)).read_text(encoding='utf-8-sig'))
        if name == 'custom-control':
            data.update({'typical_section.girder_spacing':4.0,'typical_section.deck_thickness':390.0,'typical_section.deck_overhang':0.7})
        print('PROBE START', name, flush=True)
        bridge.set_input(data)
        print('PROBE INPUT', [bridge.input_dict.get(k) for k in keys], flush=True)
        try:
            bridge.design()
        except Exception as error:
            print('PROBE ERROR', repr(error), flush=True)
        print('PROBE OUTPUT', [bridge.output_dict.get(k) for k in keys], flush=True)
        print('PROBE RESULTS', list(getattr(bridge,'design_results',{}).keys()), flush=True)
